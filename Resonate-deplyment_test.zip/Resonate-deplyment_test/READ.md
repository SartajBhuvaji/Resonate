# Resonate

# About

# Getting Started


- `git clone https://github.com/SartajBhuvaji/Resonate.git`

- Initial Setup

    `python -m venv .venv`

    `./.venv/Scripts/Activate.ps1`

    `pip install -r requirements.txt --upgrade`
    
    `./.venv/Scripts/Activate.ps1`


- Run

    `streamlit run app.py`



# Diagrams


# Acknowledgement